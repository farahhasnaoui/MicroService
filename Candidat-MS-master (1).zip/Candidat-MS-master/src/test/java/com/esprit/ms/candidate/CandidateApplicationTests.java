package com.esprit.ms.candidate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CandidateApplicationTests {

	@Test
	void contextLoads() {
	}

}
