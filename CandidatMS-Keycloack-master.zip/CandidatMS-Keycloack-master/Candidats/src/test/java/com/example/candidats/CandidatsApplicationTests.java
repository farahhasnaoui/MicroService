package com.example.candidats;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CandidatsApplicationTests {

    @Test
    void contextLoads() {
    }

}
